<?php
session_start();

extract($_POST);

require 'PDO.php';



    global $PDO;
    $sql = "INSERT INTO commentaire (user,commentaire)";
    $sql.="values (:user,:commentaire)";

    $result = $PDO -> prepare($sql);
    $result -> bindValue(':user', $_SESSION['user'], PDO::PARAM_INT);
    
    $result -> bindValue(':commentaire', $commentaire, PDO::PARAM_STR);
    
    $result -> execute()or die(print_r($result->errorInfo()));
   
    $data['pseudo']=$_SESSION['user'];
$data['mes_user']=$_SESSION['username'];



require 'imagealea.php';

echo "<div id='ligne'>";
    echo "<div class='flex' id='test'>"
                        ."<div class='flex' id='discordChat2'>".ImageAlea()."</div>"
                        ."<div  id='pseudoCommentaire'>"
                        
                        ."<div  id='pseudo'>"
                        .$_SESSION['username']
                        // ."<div class='flex' id='date'>".$data['date']."</div>"."</div>"
                        ."<div class='flex'  id='commentaire'>".$commentaire."</div>"
                    ."</div>"."</div>"; 
                    echo "</div>";




?>
