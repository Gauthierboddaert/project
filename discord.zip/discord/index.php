<?php 
  session_start();

 require 'PDO.php';
  global $PDO;

  extract($_POST);


  if(isset($_POST['username'])){
    $sql="select * from utilisateur where mes_user=:mes_user";
    $verif=$PDO->prepare($sql);
    $verif->bindValue(':mes_user',$_POST["username"]);

    $verif->execute();
    $resultat=$verif->fetchAll();

    $_SESSION["username"]=$resultat[0]['mes_user'];
    $_SESSION["user"]=$resultat[0]['id'];

  }
  // verification si le user existe 
  if (!isset($_SESSION["username"])){
    header('Location: connexion.php');
    exit;
  }

    
  
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/discord.js "></script>
    <link rel="stylesheet" href="css/discord.css">


    <title>Discord</title>

</head>

<body class="flex">

    <div id="content" class="flex">
        <!-- tous le côté gauche  -->
        <div id="left" class="flex">
            <div id="search" class="flex">
                <img id="discordImg" src="img/discord1.png" id="imgDiscord">
                <input type="text" class="inputBlack" placeholder="Rechercher un ami !">
            </div>
            <div id="friends" class="flex">
                <input type="button" value="Amis" id="buttonAmis">
                <input type="button" value="Ajouter un amis" id="buttonAmis"><br>
                <p > MESSAGE PRIVES</p>
                <div class="flex" id="butlog">
                    <a class="flex" id="logout" href="logout.php">logout</a>
                </div>
              


                <!-- <form class="flex" id="formUser" method="post" action="">
                    
                            <textarea 
                             id="nomUtilisateur" placeholder=" Entrer votre pseudo ici"></textarea>
                           
                                <button id="sendmsg2" type="submit"  class="flex">
                                    <img id="sendLogo2" width="40px"src="img/user.png" alt="">
                                </button>
                     
                </form> -->
                

            </div>
        </div>
        <!-- fin de la div gauche -->

        <!-- début de la div droite -->
        
        <div id="right" class="flex">
            <div class="flex" id="tousLeSalon">
                <div id="salon" class="flex">
                    <h2>#M3104||Prog-client-riche</h2>
                </div>
                <div class="flex" id=postUser>
                <div>Vous êtes connecté en tant que <?php echo ($_SESSION["username"]) ?></div>
                </div>
             </div>
             

            <div id="chat" class="flex">

            <?php
            require 'PDO.php';     
            $sql = $PDO->prepare('SELECT * FROM `commentaire` inner join utilisateur on utilisateur.id = commentaire.user');
            
            $sql->execute();    
            $sql->fetch(PDO::FETCH_ASSOC);
            
            //permet de génerer des images aléatoirement 
            function ImageAlea(){
                $nbimage=6;
                $resultat = rand(1,$nbimage);
            
                return "<img id='imgDiscord' id='discordChat' src='img/discord".$resultat.".png'/>";
            }           
            
            
            echo "<div id='ligne'>";
            while($data=$sql->fetch()){
                echo "<div class='flex' id='test'>"
                        ."<div class='flex' id='discordChat2'>".ImageAlea()."</div>"
                        ."<div  id='pseudoCommentaire'>"
                        ."<div class='flex' id= 'datepseudo'>"
                        ."<div  id='pseudo'>"
                        .$data['mes_user']."</div>"
                        ."<div class='flex' id='date'>".$data['date']."</div>"."</div>"
                        ."<div class='flex'  id='commentaire'>".$data['commentaire']."</div>"
                        
                    ."</div>"."</div>";
                
            }
            echo "</div>";

            //met dans la base de donnée 
            


            ?> 
            </div>

            <div id="footer" class="flex">
                <form id="form">
                    <textarea id="message" class="flex" type="text" cols="1" placeholder=" Envoyer un message à "></textarea>
                    <!-- <input type="submit" value="" id="send" class="flex">   -->
                    <button id="sendmsg" type="submit"  class="flex">
                        <img id="sendLogo" width="40px"src="img/send.jpg" alt="">
                    </button>
                    <!-- <input type="submit" name="" value=""> -->
                </form>
                


            </div>

        </div>
    </div>


</body>

</html>
