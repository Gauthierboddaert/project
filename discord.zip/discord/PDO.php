

<?php

$DBHOST = "localhost";
$DBDRIVER = "mysql";
$DBNAME = "discord";
$DBUSER = "root";
$DBPASSWORD = "";



try{
    $GLOBALS['bdd']=new PDO("$DBDRIVER:host=$DBHOST;dbname=$DBNAME","$DBUSER","$DBPASSWORD");
   

}

catch(Exception $e){

    die("ERREUR : ".$e->getMessage());

}







?>