<?php 
    session_start();
    if(isset($_SESSION['user'])){
        header("Location: index.php");
        die();
    }

    ?>


<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/discord.js "></script>
    <link rel="stylesheet" href="css/discord.css">


    <title>connexion</title>

</head>

<body>

    
        

    <div class="flex" id="pageco">
        <form class="flex" id="connexion" action="index.php"  method="POST">
            
            <input class="co2"  type="text" name="username" placeholder="Prenom" value="">

            <input class="co2" id="buttonco"  type="submit" name="" value="connexion">
        </form>
    </div>

</body>