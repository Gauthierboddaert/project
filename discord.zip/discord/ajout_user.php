<?php

extract($_POST);

require 'PDO.php';



    global $PDO;
    $sql2 = "INSERT INTO commentaire (user)";
    $sql2.="values (:user)";

    $resulte = $PDO -> prepare($sql2);
    $resulte -> bindValue(':user', $user, PDO::PARAM_STR);
    $resulte -> execute()or die(print_r($resulte->errorInfo()));



?>
