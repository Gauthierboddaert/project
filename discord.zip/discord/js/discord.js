$(document).ready(function() {
    
    element = document.getElementById('chat');
    element.scrollTop = element.scrollHeight;

    //Permet de d'entrer le message au clavier
    $(document).keydown(function(e) {
        //  alert(e.keyCode);
        switch (e.keyCode) {
            case 13:
            $("button[type=submit]").trigger("click");
            break;
        }

      

    });


    $("#form").submit(function(e){
       e.preventDefault();
        var com = $(this).find("textarea[id=message]").val();
        
        //clean la barre
        $("#message").val("");
        $.ajax({
            type : 'POST',
            url  : 'ajout_commentaire.php',
            data : {commentaire:com}  ,
            success: function(data){
                $('#ligne').append(data);
                                
            }
        });
        
        

        return false;
    });

   

});
