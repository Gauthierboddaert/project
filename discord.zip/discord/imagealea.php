<?php
 function ImageAlea(){
                $nbimage=6;
                $resultat = rand(1,$nbimage);
            
                return "<img id='imgDiscord' id='discordChat' src='img/discord".$resultat.".png'/>";
            }    

?>