<?php

    // var_dump($_POST);

    $mail='ici le mail';
    $sujet=$_POST['sujet'];
    $message2 = $_POST['message'];
    $Nom = $_POST['nom'];
    $email = $_POST['email'];
    
    if(empty($mail) or empty($sujet) or empty($message2) or empty($Nom) or empty($email)  ){
        
        echo("erreur");
    }


    $retour = mail($mail, $sujet, $message2 , 'From : http://localhost/php/mon_site/index.php');
    if($retour){
        header("location: index.php");
    }
?>

