<?php
    include 'menu.php';
?>

<body class="flex">
    <div id="backgroundContact" class="flex">
       <form class="flex" method="post" action="mail.php">
            <h1>Envoyez Nous un message</h1>
            <div id="allInput" class="flex">
                <div class="flex" id="input">
                    <div class="input">
                        <input id="champ" name="nom"  placeholder="Nom" type="text">
                    </div> 
                    <div class="input">
                        <input id="champ" name="prenom" placeholder="Prenom" type="text">
                    </div> 
                    <div class="input">
                        <input id="champ" name="sujet"  placeholder="Sujet" type="text">
                    </div>
                    <div class="input">
                        <input id="champ" name="email" placeholder="Email" type="email">
                    </div>
                </div>
                <div id="input2" class="flex">
                    <div id="champMessage" class="input">
                        <textarea placeholder="  Message" name="message" id="" cols="20" rows="10"></textarea>
                        <div class="input2">
                            <input value="Envoyer" type="submit">
                        </div>
                        
                    </div>
                </div>

            </div>
       </form>
    </div>
    <?php
        include 'footer.php';
    ?>
</body>