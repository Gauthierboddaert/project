$(document).ready(function(){
    $('#leftPart').css("display","flex");
    $("i").click(function(){
        if($(window).width() < 1297){
            
            if($("#js").hasClass("menuOFF")){

                $('#js').removeClass('menuOFF');
                $('#js').addClass('menuON');
                $('#leftPart').css("display","none");
                
                $('ul').css("display","flex");        
            }
            else{

                $('#js').removeClass("menuON");
                $('#js').addClass('menuOFF');
                $('#leftPart').css("display","flex");
                $('ul').css("display","none");
            }
        }
        
        
    });
    $('#leftPart').click(function(){
        window.location.href='index.php';
    });
   


})

function redirection(direction){
    var direction;
    document.location.href=direction;
}



// function menu(){
//     document.getElementsByClassName('test')[0].className="menuON"
// }



// const liens = document.querySelector("#contactezNous a");
// const liensArray = Array.from(liens);
// liensArray = Array.from(liens);
// liensArray.map(lien => lien.addEventListener("click", function(event) {
//     event.preventDefault();
//     location.replace("https://www.google.com.sg/maps/place/122%20rue%20de%20dunkerque,%2059630%20Bourbourg");
// }))






