<head>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200&display=swap" rel="stylesheet">
</head>

<?php
    include 'menu.php';
?>

<body style="width:100%">
    <div  class="backgroundEnergie" id="energieURL">
        <h1 data-aos="flip-up"data-aos-duration="2000" >Energies renouvelable</h1>
    </div>
    <div data-aos="fade-up" data-aos-duration="1000" id="textEnergie" class="flex">
        <div id="titreEnergie" class="flex">
            <h1>Professionnel en énergies renouvelables.</h1>
        </div>
        <div id="textProfessionnel" class="flex">
            <div id="interieurProfessionnel" class="flex">
                <h2>Des spécialistes qualifiés mettent leur savoir-faire et leurs compétences à votre écoute pour toutes vos demandes en pose, maintenance ou dépannage de : 
                    <br>-pompe à chaleur, 
                    <br>    -plancher chauffant,…</h2>
            </div>
        </div>
    </div>

   
    <script>
        AOS.init();
    </script>
</body>

<?php
        include 'footer.php';
    ?>