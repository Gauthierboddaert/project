<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/style.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <!-- GOOGLE FONT-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,100&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100&display=swap" rel="stylesheet">
        <script type="text/javascript" src="js/script.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <title>HDELEC</title>
    
</head>
<body>
    <div id="header" class="flex">
        <div id="leftPart" class="flex">
            <img id="imgLogo" onclick="redirection('index.php')" src="img/logo.jpg" alt="">
             
        </div>
        <div  id="js" class="menuOFF">
            <div id="center" class="flex">
                <ul class="ulResponsive">
                    <a class="menu" href="index.php">Accueil</a>
                    <a class="menu" href="Energies.php">Energies renouvelables</a>
                    <a class="menu" href="Chauffage.php">Chauffage</a>
                    <a class="menu" href="Sanitaire.php">Sanitaire</a>
                    <a class="menu" href="Electricite.php">Electricité</a>
                    
                    <div id="contactezNous2" onclick="redirection('contact.php')" class="flex">
                        <a href="contact.php">Contactez-Nous</a> 
                    </div>
                </ul>
            </div>
            <i style="color:#333333;" class="fas fa-bars"></i>
        </div>
        
        <div id="rightPart" class="flex">
            <ul id="ulResponsive">
                <a class="menu" href="index.php">Accueil</a>
                <a class="menu" href="Energies.php">Energies renouvelables</a>
                <a class="menu" href="Chauffage.php">Chauffage</a>
                <a class="menu" href="Sanitaire.php">Sanitaire</a>
                <a class="menu" href="Electricite.php">Electricité</a>
                
                <div id="contactezNous" onclick="redirection('contact.php')" class="flex">
                    <!-- <img src="img/hamburger-menu.webp" alt=""> -->
                    
                    <a href="contact.php">Contactez-Nous</a> 
                </div>
            </ul>
        </div>
        
    </div>
   
</body>
</html>