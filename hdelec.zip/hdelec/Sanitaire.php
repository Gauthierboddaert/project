<head>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200&display=swap" rel="stylesheet">
</head>

<?php
    include 'menu.php';
?>

<body>
    <div class="backgroundEnergie" id="sanitaireURL">
        <h1 data-aos="flip-up"data-aos-duration="2000" >Sanitaire</h1>
    </div>
    <div data-aos="fade-up" data-aos-duration="1000" id="textEnergie3" class="flex">
        <div id="titreEnergie" class="flex">
            <h1>Professionnel en installation sanitaire.</h1>
        </div>
        <div id="textProfessionnel" class="flex">
            <div id="interieurProfessionnel" class="flex">
                <h2>Nos plombiers interviennent pour : <br> <br>
                    -la conception de votre installation, <br>
                    -la mise en place d’un système de canalisation,<br>
                    -la rénovation de vos appareils (robinets, tuyaux, équipements d’évacuation d’eau),<br>
                    -la pose de sanitaires (évier, baignoire, douche, WC), <br>
                    -la conception et la pose de votre cuisine
                    </h2>
            </div>
        </div>
    </div>

    <?php
        include 'footer.php';
    ?>
    <script>
        AOS.init();
    </script>
</body>