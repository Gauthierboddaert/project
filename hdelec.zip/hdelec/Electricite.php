<head>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200&display=swap" rel="stylesheet">
</head>

<?php
    include 'menu.php';
?>

<body>
    <div class="backgroundEnergie" id="electriciteURL">
        <h1 data-aos="flip-up"data-aos-duration="2000" >Energies renouvelable</h1>
    </div>
    <div data-aos="fade-up" data-aos-duration="1000" id="textEnergie4" class="flex">
        <div id="titreEnergie" class="flex">
            <h1>Une prise en charge totale de vos travaux d’électricité générale.</h1>
        </div>
        <div id="textProfessionnel" class="flex">
            <div id="interieurProfessionnel3" class="flex">
                <h2>Nos électriciens qualifiés vous accompagnent pour: <br>
                    -le dépannage électrique,<br>
                    -l’installation ou la réparation des prises et des circuits électriques,<br>
                    -le contrôle d’armoires électriques,<br>
                    -la rénovation électrique,<br>
                    -la mise en place de luminaires et d’appareillages,<br>
                    -la pose de systèmes de sécurité (alarme, interphone, vidéosurveillance)...<br><br>

                    Nous respectons les délais d’interventions convenus. Nous vous livrons un devis gratuit suite à votre demande <br>

                    Pour plus de renseignements, appelez-nous au 03.28.23.28.27</h2>
            </div>
        </div>
    </div>

    <?php
        include 'footer.php';
    ?>
    <script>
        AOS.init();
    </script>
</body>