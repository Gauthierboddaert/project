<html>
    <head>

    </head>

    <body class="flex">

        
        <div id="body" class="flex">
            <!-- DEBUT MENU -->
            <?php 
                require 'menu.php';

            ?>
            <!-- FIN MENU -->

            <!-- CONTACT INFO -->
            <div id="backgroundBricolage" class="flex">

                <div data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000"id="PopUpContact" class="flex">

                    <div class="flex" id="metier">
                        <h2 id="nomMetier">Artisan</h2>
                        <h2 id="nomMetier2">Professionnel</h2>
                    </div>
                    
                    <div id="textMetier" class="flex">

                        <h2>Electricitien Nord-Pas-De-Calais</h2>
                    </div>
                    <div class="flex" id="textMetier2"> 

                        <h3>Contactez-nous pour un dépannage,
                            une installation, une réparation 
                            ou autres</h3> 

                    </div>
                    <div class="flex" id="tel">
                        <h3>03 28 23 28 27</h3>
                    </div>
                     
                </div>

                </div>
                <!-- FIN CONTACT INFO -->

                <!-- MES SERVICES -->
                <div id="mesServices" class="flex">
                    <h1>Nos Services</h1>
                </div>
                <div id="backgroundService" class="flex">
                    <div onclick="redirection('Electricite.php')" data-aos="flip-right" data-aos-duration="2000" data-aos-anchor-placement="center-bottom" class="box">
                        <div id="ampoule" class="services">   
                        </div>
                        <div class="DescriptionsService">
                            <h1>Électricité</h1>
                            <p>Que vous soyez particuliers ou professionnels, HD Elec vous garantit une prise en charge totale de vos travaux d’électricité générale.</p>
                        </div>
                    </div>
                </div>
                <div id="backgroundService" class="flex">
                    <div onclick="redirection('Sanitaire.php')" data-aos-duration="2000" data-aos="flip-left" data-aos-anchor-placement="center-bottom" class="box">
                        <div id="robinet" class="services">   
                        </div>
                            <div class="DescriptionsService">
                                <h1>Sanitaire</h1>
                                <p>L’entreprise HD Elec est chargée de l’installation sanitaire auprès des particuliers et des professionnels à Bourbourg et ses alentours.</p>
                            </div>
                    </div>
                </div>
                <div id="backgroundService" class="flex">
                    <div onclick="redirection('Chauffage.php')" data-aos="flip-right" data-aos-duration="2000" data-aos-anchor-placement="center-bottom" class="box">
                        <div id="chauffage" class="services">   
                        </div>
                            <div class="DescriptionsService">
                                <h1>chauffage</h1>
                                <p>Les chauffagistes de HD Elec sont disponibles pour vous présenter des prestations en installation, mise en service, dépannage ou maintenance de tous types de chauffage</p>
                            </div>
                    </div>
                </div> <div id="backgroundService" class="flex">
                    <div onclick="redirection('Energies.php')" data-aos-duration="2000" data-aos="flip-left" data-aos-anchor-placement="center-bottom" class="box">
                        <div id="energie" class="services">   
                        </div>
                        <div class="DescriptionsService">
                            <h1>Energies renouvelables</h1>
                            <p>HD Elec est votre professionnel en énergies renouvelables à Bourbourg et ses alentours.</p>
                        </div>
                    </div>
                </div> 

                <!-- FIN MES SERVICES -->

                <?php
                    include 'footer.php';
                ?>
                
        </div>
        <script>
            AOS.init();
        </script>
    </body>


</html>