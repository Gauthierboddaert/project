<head>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@200&display=swap" rel="stylesheet">
</head>

<?php
    include 'menu.php';
?>

<body>
<div  class="backgroundEnergie" id="chauffageURL">
        <h1 data-aos="flip-up"data-aos-duration="2000" >Chauffage</h1>
    </div>
    <div data-aos="fade-up" data-aos-duration="1000" id="textEnergie2" class="flex">
        <div id="titreEnergie" class="flex">
            <h1>Des chauffagistes Professionnel.</h1>
        </div>
        <div id="textProfessionnel" class="flex">
            <div id="interieurProfessionnel2" class="flex">
                <h2>Disponible pour des prestations en installation, mise en service, dépannage ou maintenance de tous types de chauffage : <br>
                -chauffage électrique, bois, gaz ou fioul,<br>
                -pompe à chaleur,<br>
                -chauffage solaire, <br>
                -chaudière et radiateur,…
                </h2> <br>
                <h2>Nous répondons à vos demandes sur simple appel téléphonique et vous proposons des conseils personnalisés afin d’augmenter la longévité de vos installations. </h2>

                <h2><a href="contact.php" >Contactez-nous</a> pour plus de renseignements. Nous serons ravis de vous répondre.</h2>
                
            </div>
        </div>
    </div>
    <?php
        include 'footer.php';
    ?>
   
    <script>
        AOS.init();
    </script>
</body>