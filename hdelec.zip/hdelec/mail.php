<?php

    $mail='boddaert.gauthier@gmail.com';
    $sujet=$_POST['sujet'];
    $message = $_POST['message'];
    $Nom = $_POST['nom'];
    $Prenom = $_POST['prenom'];
    $email = $_POST['email'];
    $header = 'From:'.$email. "\r\n" .
    'Reply-To : '.$email. "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    

    if($message!="" and $Nom!="" and $sujet!="" and $Prenom!="" and $email!=""){
        mail($mail, $sujet, $message , $header);
        header('Location: contact.php');
        
    }else{
        header('Location: index.php');
    }



    
    // if ($retour) {
    //     echo '<p>Votre message a bien été envoyé.</p>';
    //     header('Location: contact.php');
    // }else{
    //     echo "<p>Echec de l'envoie";
    //     header('Location: contact.php');
    // }

    ?>
    