<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Gauthier Boddaert</title>
  <link rel="stylesheet" href="css/index.css">
  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="js/index.js"></script>
  <script src="https://kit.fontawesome.com/f46c575059.js" crossorigin="anonymous"></script>
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Long+Cang&display=swap" rel="stylesheet">
  
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&family=Poppins:wght@300&display=swap" rel="stylesheet">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">



  
</head>

<body>
	
  <!-- header -->
	<header class="flex" >
		<div class="flex" id="titre">
			<h1>MON PORTFOLIO</h1>
		</div>
	</header>
<!-- menu -->
	<nav class="flex">
		<ul class="flex">
			<li><a class="scroll" href="">Présentation</a></li>
			<li><a class="scroll"  href="#Propos">A propos de</a></li>
			<li><a class="scroll"  href="#compétence">Mes compétences</a></li>
			<li><a class="scroll" href="#contact">Me contacter</a></li>
		</ul>
	</nav>
	<!-- Menu présentation -->
	<div class="flex" id="Presentation">
		<div class="flex" id="TitrePresentation">
			<h1>GAUTHIER BODDAERT</h1>
		</div>
		<div class="flex" id="PhrasePresentation">
			<h1>Actuellement en 2ème année de DUT informatique</h1>
		</div>
		<div class="flex" id="PhrasePresentation2">
			<h1>En recherche d'un contrat en alternance</h1>
		</div>
	</div>  

	<!-- A propos de -->
	<a name="Propos"></a>
	<div class="flex" id="content">
		<div class="flex" id="backgroundPropos" >
			<div class="flex" id="DivPropos">
				<h1>À propos de moi</h1><br>
				<div class="flex" id="ContenuPropos">
					<h3 id="AproposDemoi">J'ai 19 ans et je suis étudiant en 2ème DUT informatique à Calais. J'ai fait un bac STAV (Science Techonologie Agronomie Vivant) à <a href="https://wp.iet-hoymille.fr/">l'IET de hoymille.</a>
						J'ai découvert l'informatique (les langages de programmation) en Terminal et c'est ainsi que je me suis orienté dans le milieu de la technologie.
						Durant ces deux années nous avons appris plusieurs langages informatique (java, HTML/CSS, php, js ...). </h3>
				</div>
			</div>
			<div class="flex">
				<img id="moi" src="img/moi2.jpg" alt="">
			</div>
		</div>
	</div>


						
	<!-- Div mes compétences -->
	<a name="compétence"></a>
	<div class="flex" id="DivMesCompetences">
		<div class="flex" id="backgroundTitreMesCompétences">
			<h1>Mes compétences</h1>
		</div>
	</div>


	<div class="flex" id="mesCompetences">
	
		<div class="container">
			<div class="row">
				<ul>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab  item">
						<div class="folded-corner service_tab_1">
							<div class="text">
								<i class="fab fa-html5 fa-5x fa-icon-image"></i>
									<p class="item-title">
											<h3> Html</h3>
										</p><!-- /.item-title -->
								<p>
									J'ai de très bonne connaisance en Html, nous avons eu des cours en première année, nous avons fait beaucoup de projet à l'aide de ce langage.
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
								<i class="fab fa-css3-alt fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> Css</h3>
									</p><!-- /.item-title -->
									<p>
										Comme en en Html, j'ai de bonne connaisance en Css, nous avons eu des cours en première année, nous avons fait beaucoup de projet à l'aide de ce langage.                                                   
									</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
								<i class="fab fa-js-square fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> JavaScript</h3>
									</p><!-- /.item-title -->
								<p>
									Durant notre deuxième semestre, nous avons eu plusieurs projet durant lesquelles nous avons beacoup utilisé la bibliothèque Jquery. 
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
							<i class="fab fa-php fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> PHP</h3>
									</p><!-- /.item-title -->
								<p>
									Au cours de ma deuxième année j'ai découvert le Php, j'ai des connaisance dans ce langage, les projets m'ont permis de m'améliorer dans ce langage 
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
							<i class="fab fa-bootstrap fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> Bootstrap</h3>
									</p><!-- /.item-title -->
								<p>
									J'ai étudié le framework Bootstrap sur mon temps libre car je trouvais que celui-ci apporté des avantages pour le responsive. 
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
								<i class="fab fa-github fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> Github</h3>
									</p><!-- /.item-title -->
								<p>
									J'ai découvert Github lors de la réalisation de projet en groupe, j'ai trouvé cette plateforme très utile lors des projets de groupe
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
								<i class="fab fa-python fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> Python</h3>
									</p><!-- /.item-title -->
								<p>
									J'ai fait du python lors de ma première année, je ne suis pas très à l'aise avec ce langage de programmation.
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
						<div class="folded-corner service_tab_1">
							<div class="text">
							<i class="fab fa-java fa-5x fa-icon-image"></i>
									<p class="item-title">
										<h3> java</h3>
									</p><!-- /.item-title -->
								<p>
									Nous avons fait du java durant nos deux année de DUT informatique, je n'ai jamais utilisé des frameworks web tels que spring
								</p>
							</div>
						</div>
					</div>
				</ul>
			</div>
		</div>
	</div>
	
						<!-- FIN DES COMPETENCES -->
	
	<a name="contact"></a>
	<div class="flex" id="BackgroundContact">
		<div class="flex" id="DivMeContacter">
			<div class="flex" id="BackgroundTitreMeContacter">
				<h1>Me contacter</h1>
			</div>
		</div>
		<div class="flex" id="FormualaireContact">
			<div class="flex" id="DivContact">
				<div class="flex" id="TitreContact">
					<form class="flex" method='post' action="mail.php">
						<div class="flex" id="Formulaire">

							<div class="flex" class="ligneFormulaire">
								<input placeholder="Nom" type="text" class="ZoneDeTexte" name="nom">
								<input placeholder="Prenom" type="text" class="ZoneDeTexte" name="prenom">
							</div>

							<div class="flex" class="ligneFormulaire">
								<input placeholder="Telephone" type="text" class="ZoneDeTexte" name="tel">
								<input placeholder="E-mail" type="text" class="ZoneDeTexte" name="email">
							</div>

							<div class="flex" class="ligneFormulaire">
								<input placeholder="Sujet" type="text" class="Sujet" name="sujet">
							</div>	

							<div class="flex" class="ligneFormulaire">
								<textarea  placeholder="Message" name="message" id="Messagetexte" cols="30" rows="10"></textarea>
							</div>

							<div id="buttonEnvoyer" class="flex">
								<input id="button" value="Envoyer" type="submit">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
  

</body>
</html>
