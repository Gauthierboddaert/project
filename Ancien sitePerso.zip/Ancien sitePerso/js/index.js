// $(document).ready(function(){
//     $('#button').click(function(){
//         alert('coucou');
//     })
    
// })

function openModal(){
    document.getElementById("modal").style.top="0px";
}