<head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="js/index.js "></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
   
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Long+Cang&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js%22%3E"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&family=Poppins:wght@300&display=swap" rel="stylesheet">
 
<!-- Latest compiled JavaScript -->

<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Gauthier Boddaert</title>

</head>

<div class="container">
<div class="row">
<ul>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab  item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-image fa-5x fa-icon-image"></i>
                    <p class="item-title">
                            <h3> Designing</h3>
                        </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-lightbulb-o fa-5x fa-icon-image" ></i>
                    <p class="item-title">
                        <h3> Developing</h3>
                    </p><!-- /.item-title -->
                    <p>
                        This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-truck fa-5x fa-icon-image"></i>
                    <p class="item-title">
                        <h3> Marketing</h3>
                    </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-diamond fa-5x fa-icon-image"></i>
                    <p class="item-title">
                        <h3> Branding</h3>
                    </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
        <div class="text">
            <i class="fa fa-line-chart fa-5x fa-icon-image"></i>
                <p class="item-title">
                    <h3>Analytics</h3>
                </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-mobile fa-5x fa-icon-image"></i>
                    <p class="item-title">
                        <h3>Mobil Apps</h3>
                    </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
            <div class="folded-corner service_tab_1">
                <div class="text">
                    <i class="fa fa-money fa-5x fa-icon-image"></i>
                        <p class="item-title">
                            <h3> e-commerce</h3>
                        </p><!-- /.item-title -->
                    <p>
                        This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                    </p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 Services-tab item">
        <div class="folded-corner service_tab_1">
            <div class="text">
                <i class="fa fa-bullhorn fa-5x fa-icon-image"></i>
                    <p class="item-title">
                        <h3> Support</h3>
                    </p><!-- /.item-title -->
                <p>
                    This is an amazing set of animated accordions based completely on CSS. They come oriented both vertically and horizontally in order to fit properly in your project. In order to see the slides, 
                </p>
            </div>
        </div>
    </div>
   </ul>
</div>
</div>


