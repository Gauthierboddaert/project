<html>
<head>
    <meta charset="utf-8">
    <title>Récapitulatif des informations</title>
    <link rel="stylesheet" href="css/index.css">
    <script src="js/index.js" type="text/javascript"></script>
</head>

<body>
    <?php

    // var_dump($_POST);

    $mail='boddaert.gauthier@gmail.com';
    $sujet=$_POST['sujet'];
    $message2 = $_POST['message'];
    $Nom = $_POST['nom'];
    $Prenom = $_POST['prenom'];
    $Telephone = $_POST['tel'];
    $email = $_POST['email'];
    
    $retour = mail($mail, $sujet, $message2 , 'From : http://localhost/php/mon_site/index.php');
    if ($retour) {
        echo '<p>Votre message a bien été envoyé.</p>';
    }else{
        echo "<p>Echec de l'envoie";
    }
    


    //Création du PDO
  

    $DBHOST = "localhost";
    $DBDRIVER = "mysql";
    $DBNAME = "gauthier";
    $DBUSER = "root";
    $DBPASSWORD = "";


    try {
        $PDO = new PDO("$DBDRIVER:host=$DBHOST; dbname=$DBNAME","$DBUSER",$DBPASSWORD);
        
    }
    catch (PDOexception $e){
        
    }

    global $PDO;

    if($message2){
        $sql = "INSERT INTO data_user (Nom, Prenom, Telephone, Sujet, message, email)";
        $sql.="values (:Nom, :Prenom, :Telephone, :Sujet, :message, :email)";
        $result = $PDO -> prepare($sql);
        $result -> bindValue(':message', $message2, PDO::PARAM_STR);
        $result -> bindValue(':Nom', $Nom, PDO::PARAM_STR); 
        $result -> bindValue(':Prenom', $Prenom, PDO::PARAM_STR); 
        $result -> bindValue(':Telephone', $Telephone, PDO::PARAM_STR); 
        $result -> bindValue(':Sujet', $sujet, PDO::PARAM_STR); 
        $result -> bindValue(':email', $email, PDO::PARAM_STR); 
        $result -> execute() ;
        

       
    }
  



    ?>
<div class="flex" id="backgroundRecapitulatif">
    <div class="flex" id=cadreRecapitulatif>
        <h1>Récapitulatif des coordonnées</h1>
        <?php
            echo '<div class="recapitulatif"> <h2>Nom : '.$Nom.'</h2></div>';      
            echo '<div class="recapitulatif"> <h2>Prenom : '.$Prenom.'</h2></div>';  
            echo '<div class="recapitulatif"> <h2>Téléphone : '.$Telephone.'</h2></div>';  
            echo '<div class="recapitulatif"> <h2>e-mail : '.$email.'</h2></div>'; 
            ?>
            <div id="buttonEnvoyer2" class="flex">
                <button id="button2" onclick="openModal()">Valider</button>
                    <!-- <input id="button2" value="Valider" type="submit"> -->
            </div>               
            
        <?php
            echo '<div class="revenir"> <a href="index.php">Revenir à la page précedente</a></div>';  
        ?>
         <div id="modal">
            <h2>Votre e-mail a bien été envoyer</h2>
        </div>
    </div>
</div>

    
</body>
</html>