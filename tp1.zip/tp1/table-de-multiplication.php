<?php
require  '../tag.lib.php';
//mon code ne marche pas quand j'utilise mes balises, donc je met en commentaires pour montrer que j'ai essayé 

$css = "table-de-mupltiplication"; // nom de ton fichier css
$title = "Table de multiplication"; // titre de la page

//distinguer le première appel
if(!isset($_GET['table']))$_GET['table']=1;

//Check des données
if(!is_numeric($_GET['table']))$_GET['table']=1;

    if($_GET['table']<1 or $_GET['table']>10)$_GET['table']=1;

    $table = $_GET['table'];

$content="<form action='{$_SERVER['PHP_SELF']}' method='get'>";


//$content. = select('table',array('onChange' = > 'this.form.submit()'))
$content.='<select name ="table" onChange="this.form.submit();"';
for ($i = 0; $i < 11; $i++){
    $content.="<option value='$i' ";
    if($table==$i)$content.=" selected";
    $content.=">$i</option>\n";
}
//$content. = fermer('select').closetag('form').table();
$content.="</select>\n</form>\n<table style='width:80px'><tr>";
for($i = 1; $i <= 10; $i++){
    $r=$i*$table;
    // $content. = ouvrir('tr').ouvrir('td').$table.'x'.$i.'='.$r.fermer('td');
    $content.="<tr><td>$table<td>x</td> <td>$i</td>  <td>=</td><td> $r</td></tr>";
}
//$content. = fermer('tr').$table;
$content.="</tr></table>";
require 'gabarie.php';
?>

