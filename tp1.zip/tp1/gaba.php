<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" href="<?=$css?>.css">
<title><?=$title?></title>  
</head>
<h1>Convertisseur Franc/Euros</h1>
<body>

<h3>Francs :</h3></body>
</html>

