<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<link rel="stylesheet" href="<?=$css?>.css">
<title><?=$title?></title>
<h1>Table de multiplication</h1>
</head>
<body><?=$content?></body>
</html>
