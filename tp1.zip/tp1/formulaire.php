<?php
if (!isset($_GET['table'])) $_GET['table']=1;
$css = "formulaire";
$title="Choissez votre chiffre";
$content='<p>Choissiez votre chiffre</p><form action="table-de-multiplication.php" method="post"><select name="numero" onchange="this.form.submit();">';

    for ($n = 1; $n <= 10; $n++) {                      //boucle de 1 à 10
           $content.= "<option value=$n";               //ouverture de la balise html option
      if ($n == $_GET['table']) $content.= " selected"; //ne pas enlever espace avant selected (ça va sortir selected="true" en html)
           $content.= ">$n</option>";                   //fermeture de la boucle
    }

$content.='</select></form><br>';
require 'gabarie.php';
?>
