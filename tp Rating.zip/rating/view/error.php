<?php

require "view/config.php";

require "view/tags.lib.php";

if($PROD){

    $content = head("Error $Error",3);
    $content.= paragraphe("Merci de contacter $WEBMST !");
}else{

    $content = head("Error $Error",3);
    $content.= paragraphe($ERROR_MESSE[$ERROR]);

}

require "views/gabari.php";


?>