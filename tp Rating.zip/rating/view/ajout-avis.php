<?php

$title ="";
$content = "";

require 'controller/tag.lib.php';
require 'model/ajout-avis.php';

/*echo'
<form action="?controller=avis-lister" method="post">
 <p>Votre nom : <input type="text" name="nom" /></p>
 <p>Votre âge : <input type="text" name="age" /></p>
 <p><input type="submit" value="OK"></p>
</form>';*/


$content = formulaire(
    //premier cadre
    input("note", "note", "", "", array('placeholder' => '4')).nl().nl().

    //deuxieme cadre
    input('commentaire  ', "commentaire", "", "", array('placeholder' => 'Très bien !')).nl().nl().   

    //troisième cadre
    input('Etudiants  ', "etudiants", "", "", array('placeholder' => 'Dupond')).nl().nl().    

    //quatrième cadre
    input('Departement  ', "departement", "", "", array('placeholder' => 'DUT INFO 2')).nl().nl().    

    //cinquième cadre
    input('Promo  ', "promo", "", "", array('placeholder' => '2eme annee')).nl().nl().    

    //sixième cadre
    input('Module  ', "module", "", "", array('placeholder' => 'M3104')).nl().nl().

    input('Envoyer ', "envoyer", "", "submit", array ())
    ,"{$_SERVER['PHP_SELF']}?controller=avis-lister","POST"
);

require 'view/gabari.php';

?>
