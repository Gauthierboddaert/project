<?php


require "controller/tag.lib.php";
$title = "TABLE DES AVIS ";


$table="";

$Prems=true;

foreach (get_avis() as $cle) {
    $row= "";
        if($Prems){
            foreach ($cle as $nomCol => $value){
                $row .= cell($nomCol,"true");
                $Prems=false;
            }
            $table=row($row);
            $Prems=false;
        }
    $row= "";
            foreach ($cle as $cle2 => $value) {
                $row.=cell($value);
            }

    $table .= row($row);
}
$content=table($table);


//insertion des données du formulaire dans la base
$com = $_POST['commentaire'];
$note = $_POST['note'];
$etudiants = $_POST['etudiants'];
$departement = $_POST['departement'];
$promo = $_POST['promo'];
$module = $_POST['module'];

require 'model/ajout-avis.php';
add_avis($note,$com,$etudiants,$departement,$promo,$module);



require "view/gabari.php";


?>