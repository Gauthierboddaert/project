<?php

$title = "SA MARCHE";

$css='default';

$header=div("SA MARCHE", array('class' => 'header'));

$footer=div("SA MARCHE YESS", array('class' => 'footer'));

$content=paragraphe("J AI REUSSI");

require 'gabari.php';
?>
