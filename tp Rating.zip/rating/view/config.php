<?php

$PROD = False;
$ERROR_MESSE= array(0 => 'pas erreur',
                2 => "erreur de chargement",
                3=> "probleme de co",
                4=> "probleme d'execution ",
                5=> "champ manquant"
                6 => "erreur integer");

$ERROR = 0;
$WEBMST="coucuo@gmail.com";


?>
