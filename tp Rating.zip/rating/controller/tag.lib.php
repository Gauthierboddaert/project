<?php

/*
titre : Permet de concevoir des titres en HTML avec les options de 1 à 6 & attibuts
*/
function titre($content, $type=1,$attributs=array()){
    return tag("h$type",$content,$attributs);
}

function nl(){
    return tag('br');
}//new line


function tag($tag, $content=null, $attributs= array(), $end='', $before='')
{
    $output="$before<$tag";
    foreach ($attributs as $name => $value) {
        if (empty($value)) {
            $output.=" $name";
        } else {
            $output.=" $name=\"$value\"";
        }
    }
    return $output.($content ? ">$content</$tag>" : '/>') .$end;
}
function paragraphe($content, $attributs=array())
{
    return tag('p', $content, $attributs, "\n");
}
function cell($content, $header=false, $attributs=array())
{
    return tag($header?'th':'td', $content, $attributs);
}
function row($content, $attributs=array())
{
    return tag('tr', $content, $attributs);
}
function table($content, $caption='', $attributs=array())
{
    return tag('table', $content.tag('caption', $caption), $attributs);
}
function head($content, $size=1)
{
    return tag('h'.$size, $content);
}
function a($sensitive, $url='#', $attributs=array())
{
    $attributs['href']=$url;
    return tag('a', $sensitive, $attributs);
}
function input($label, $name, $value=null, $type='TEXT', $attributs=array())
{
    $attributs['value']=$value;
    $attributs['name'] =$name;
    $attributs['type'] =$type;
    $output='';
    if ($label) {
        $attributs['id'] =$name;
        $output.=tag('label', $label, array('for'=>'id'));
    }
    $output.=tag('input', null, $attributs);
    return $output;
}
function formulaire($content, $action='#', $method='POST', $attributs=array())
{
    $attributs['method']=$method;
    $attributs['action']=$action;
    return tag('form', $content, $attributs);
}

/*
div : Permet de concevoir des div en HTML avec contenu & attributs
*/
function div($content, $attributs = array()){
    return tag('div',$content, $attributs);
}
