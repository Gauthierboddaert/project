<?php

require 'check.lib.php';
require 'tag.lib.php';
require 'view/home.php';
?>
