<?php

//insertion d'une base de donnée

if ($_SERVER['REQUEST_METHOD']=='POST'){
    print_r($_POST);
    echo(0);
    //vérifie si les variable n'existent pas   
    if(
        !isset($_POST['note']) or   
        !isset($_POST['commentaire']) or       
        !isset($_POST['departement']) or       
        !isset($_POST['etudiant'])
    ){    
         


        $ERROR = 5;
        require 'view/error.php';
    }

    else{
        require 'model/ajout-avis.php';
        $note =$_POST['note'];
        $commentaire=$_POST['commentaire']; 
        $etudiants =$_POST['etudiants'];
        $departement =$_POST['departement'];
        $promo=$_POST['promo'];
        $module=$_POST['module'];

        //controle du contenu de la variable $note
        $isError = false;
        
        if(!check_integer($note, 5)){
            $isError = true;
            
        }
        //controle du contenu de la variable $commentaire
        if(!check_integer($commentaire)){
            $isError = true;
        
        }

        //controle du contenue de la variable etudiants
        if(!check_integer($commentaire)){
            $isError = true;
        }

        //controle du contenue de la variable departement
        if(!check_integer($etudiants)){
            $isError = true;
        }

        //controle du contenu de la variable $promo 
        if(!check_integer($promo)){
            $isError = true;
        }

        //controle du contenu de la variable $module
        if(!check_integer($module)){
        $isError = true;
        }

        if($isError ==false){
            $ERROR =  add_avis($note,$commentaire,$etudiants,$departement,$promo,$module);
            if($ERROR!=0){
                require 'view/error.php';
            }
            else{
                echo('insertion ok');
            }
        }
        else{
            $ERROR = 6;
            require 'view/error.php';
        }
        

        
        
    }
   
   
}
else{
    echo(1);
    //affichage du formulaire 
    require 'view/ajout-avis.php';

}




?>