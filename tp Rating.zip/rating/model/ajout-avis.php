<?php

require 'model/connect-db.php';

function add_avis($note,$commentaire,$etudiants,$departement,$promo,$module){
    global $PDO;
    $sql = "INSERT INTO avis (note, commentaire, etudiant, departement, promo, module)";
    $sql.="values (:note,:commentaire,:etudiants,:departement,:promo,:module)";

    $result = $PDO -> prepare($sql);
    $result -> bindValue(':note', $note, PDO::PARAM_INT);
    $result -> bindValue(':commentaire', $commentaire);
    $result -> bindValue(':etudiants', $etudiants);
    $result -> bindValue(':departement', $departement);
    $result -> bindValue(':promo', $promo);
    $result -> bindValue(':module', $module);
    $result -> execute();

    if ($result == true){
               // return $note.' '.$commentaire.' '.$etudiants.' '.$departement.'' .$promo.' '.$module;
        return 0;
    }
    else{
        return 4;
    }
    

}
//$sql = 'INSERT INTO avis (note, commentaire, etudiant,departement,promo,module,date) values($note,$commentaire,$etudiants,$departement,$promo,$date)';
//date("Y-m-d"))
?>
