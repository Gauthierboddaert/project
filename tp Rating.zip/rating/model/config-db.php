<?php

$DBHOST = "localhost";
$DBDRIVER = "mysql";
$DBNAME = "ratingdb";
$DBUSER = "root";
$DBPASSWORD = "";

?>