<?php



function get_avis(){
    global $PDO; 
    
    $sql = $PDO->prepare('SELECT * from avis ');
    $PDO->exec("set names utf8");
    $sql->execute();    
    return $sql->fetchAll(PDO::FETCH_ASSOC);
    
    
    
       
}

require "connect-db.php";

?>