<?php

require "config-db.php";

try {
    $PDO = new PDO("$DBDRIVER:host=$DBHOST; dbname=$DBNAME","$DBUSER",$DBPASSWORD);
    

}
catch (PDOexception $e){
    require  "view/error.php";
    $ERROR = 1;
}

?>