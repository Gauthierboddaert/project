<?php


if(isset($_GET["controller"])){
    echo htmlspecialchars($_GET["controller"])."<br>";
}else{
    die("N'existe pas");
}

$test = $_GET["controller"];
if(file_exists("controller/$test.php")){
    require "controller/$test.php";
}else{
    die("Fichier Introuvable !");
}

?>
